package com.creditdecision.engine.pojo;

import java.util.Date;

public class CreditScore {
	private String ssnNumber;

	private Integer loanAmount;

	private Integer currentAnnualIncome;
	
	private String creditScore;
	
	private Date loanDate;
	
	private String message;
	
	/**
	 * @return the creditScore
	 */
	public String getCreditScore() {
		return creditScore;
	}
	/**
	 * @param creditScore the creditScore to set
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
	/**
	 * @return the loanDate
	 */
	public Date getLoanDate() {
		return loanDate;
	}
	/**
	 * @param loanDate the loanDate to set
	 */
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	/**
	 * @return the ssnNumber
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}
	/**
	 * @param ssnNumber the ssnNumber to set
	 */
	public void setSsnNumber(String ssnNumber) {
		this.ssnNumber = ssnNumber;
	}
	/**
	 * @return the loanAmount
	 */
	public Integer getLoanAmount() {
		return loanAmount;
	}
	/**
	 * @param loanAmount the loanAmount to set
	 */
	public void setLoanAmount(Integer loanAmount) {
		this.loanAmount = loanAmount;
	}
	/**
	 * @return the currentAnnualIncome
	 */
	public Integer getCurrentAnnualIncome() {
		return currentAnnualIncome;
	}
	/**
	 * @param currentAnnualIncome the currentAnnualIncome to set
	 */
	public void setCurrentAnnualIncome(Integer currentAnnualIncome) {
		this.currentAnnualIncome = currentAnnualIncome;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}



