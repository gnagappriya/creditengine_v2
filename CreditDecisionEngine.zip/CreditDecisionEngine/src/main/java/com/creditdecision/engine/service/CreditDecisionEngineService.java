package com.creditdecision.engine.service;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.creditdecision.engine.exception.InvalidDataException;
import com.creditdecision.engine.pojo.CreditRequest;
import com.creditdecision.engine.pojo.CreditScore;
import com.creditdecision.engine.pojo.Response;

@Service
public class CreditDecisionEngineService {
	private final Logger logger = LoggerFactory.getLogger(CreditDecisionEngineService.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${url.name}")
	String urlName;
	
	public Response getcreditScore(CreditRequest creditRequest) {
		logger.debug("CreditDecisionEngineService : getCreditRequest - starts ");
		
		CreditScore creditScoreRes = restTemplate.getForObject(urlName, CreditScore.class);
		Response res = new Response();
		if(creditScoreRes.getLoanAmount()>700) {
			if(getNumberOfDays(creditScoreRes.getLoanDate() )>30) {
			res.setSsnNumber(creditRequest.getSsnNumber());
			res.setSanctionAmount(creditRequest.getCurrentAnnualIncome()/2);
			}else {
				res.setMessage("Applicant with same SSN Number can’t apply or try to apply for 30 days time");
				throw new InvalidDataException("Applicant with same SSN Number can’t apply or try to apply for 30 days time");
			}
		}
		
		return res;
	}
	
	public int getNumberOfDays(Date d){
		LocalDate endofCentury = LocalDate.of(d.getYear(), d.getMonth(), d.getDay());
		LocalDate now = LocalDate.now();
		Period diff = Period.between(endofCentury, now);
		return Integer.parseInt(diff.toString());
	}
}
