package com.creditdecision.engine.exception;

public class InvalidDataException extends RuntimeException{
	public InvalidDataException(String id) {

        super(String.format("Invalid Data found", id));
    }
}
