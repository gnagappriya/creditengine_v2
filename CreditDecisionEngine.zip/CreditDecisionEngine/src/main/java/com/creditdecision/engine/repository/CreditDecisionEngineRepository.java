package com.creditdecision.engine.repository;

public class CreditDecisionEngineRepository {

}
