package com.creditscore.engine.controller;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
import com.creditscore.engine.repository.CreditScoreEngineRepository;
import com.creditscore.engine.service.CreditScoreEngineService;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CreditScoreEngineController.class, CreditScoreEngineService.class,CreditScoreEngineRepository.class,
		RestTemplate.class })
@WebAppConfiguration
class CreditScoreEngineControllerTest {

	@Mock
	CreditScoreEngineController creditScoreEngineController;


	@Mock
	CreditScoreEngineService creditScoreEngineService;
	
	@Mock
	CreditScoreEngineRepository creditScoreEngineRepository;
	
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testCreditRequest() {
		Mockito.when(creditScoreEngineService.getcreditScore(creditReq())).thenReturn(creditScore());
		ResponseEntity<CreditScore>  re = creditScoreEngineController.creditRequest(creditReq());
		Assert.assertEquals("ssn01", creditScore().getSsnNumber());
		Assert.assertEquals(700, creditScore().getCreditScore());
	}

	
	public CreditRequest creditReq() {

		CreditRequest cr = new CreditRequest();
		cr.setSsnNumber("ssn01");
		cr.setLoanAmount(1234454523);
		cr.setCurrentAnnualIncome(2342342);
		return cr;
	}

	public CreditScore creditScore() {
		CreditScore cs = new CreditScore();
		cs.setSsnNumber("ssn01");
		cs.setCreditScore("700");
		return cs;

	}
	
}
